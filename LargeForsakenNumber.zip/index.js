const { Client, Intents, Collection } = require('discord.js');
const client = new Discord.Client({ intents: ['GUILD_CREATE', 'GUILD_MEMBERS', 'GUILD_MESSAGES', 'GUILD_MESSAGE_REACTIONS'] });
const { token } = require('./config');

// Colecciones para almacenar los comandos y eventos
client.commands = new Collection();
client.events = new Collection();

// Cargar los comandos y eventos
// ...

client.login(token);

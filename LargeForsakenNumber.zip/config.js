module.exports = {
  token: 'process.env['Token'],
  prefix: '!',
  antilinkChannelName: 'antilinks', // Nombre del canal donde se enviarán los mensajes con enlaces no permitidos
  mutedRoleName: 'Muted', // Nombre del rol para silenciar usuarios
};
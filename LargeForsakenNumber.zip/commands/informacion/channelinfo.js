const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'channelinfo',
  description: 'Muestra información sobre un canal específico.',
  usage: '!channelinfo <nombre del canal>',
  example: '!channelinfo general',
  execute(message, args) {
    const channelName = args.join(' ');
    const channel = message.guild.channels.cache.find((ch) => ch.name === channelName);

    if (!channel) {
      return message.reply('No se encontró el canal especificado.');
    }

    const channelEmbed = new MessageEmbed()
      .setColor('#0099ff')
      .setTitle(`Información del canal #${channel.name}`)
      .addField('ID del canal', channel.id)
      .addField('Tipo de canal', channel.type)
      .addField('Categoría', channel.parent ? channel.parent.name : 'Ninguna')
      .addField('Fecha de creación', channel.createdAt);

    message.channel.send({ embeds: [channelEmbed] });
  },
};
                          
const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'serverinfo',
  description: 'Muestra información detallada sobre el servidor.',
  execute(message) {
    const server = message.guild;
    const serverEmbed = new MessageEmbed()
      .setColor('#0099ff')
      .setTitle(`Información del servidor ${server.name}`)
      .addField('ID del servidor', server.id)
      .addField('Dueño del servidor', server.owner.user.tag)
      .addField('Total de miembros', server.memberCount)
      .addField('Total de roles', server.roles.cache.size)
      .addField('Total de canales', server.channels.cache.size)
      .addField('Fecha de creación', server.createdAt);

    message.channel.send({ embeds: [serverEmbed] });
  },
};

const { MessageEmbed, version: discordVersion } = require('discord.js');
const { version } = require('../package.json');

module.exports = {
  name: 'botinfo',
  description: 'Muestra información detallada sobre el bot.',
  execute(message) {
    const botEmbed = new MessageEmbed()
      .setColor('#0099ff')
      .setTitle('Información de Sally (tu bot)')
      .addField('Versión del bot', version)
      .addField('Versión de Discord.js', discordVersion)
      .addField('Desarrollador', 'acx17')
      // .setFooter(' pronto');

    message.channel.send({ embeds: [botEmbed] });
  },
};

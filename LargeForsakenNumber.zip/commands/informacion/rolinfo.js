const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'roleinfo',
  description: 'Muestra información sobre un rol específico.',
  usage: '!roleinfo <nombre del rol>',
  example: '!roleinfo MiRol',
  execute(message, args) {
    const roleName = args.join(' ');
    const role = message.guild.roles.cache.find((r) => r.name === roleName);

    if (!role) {
      return message.reply('No se encontró el rol especificado.');
    }

    const roleEmbed = new MessageEmbed()
      .setColor(role.color)
      .setTitle(`Información del rol ${role.name}`)
      .addField('ID del rol', role.id)
      .addField('Color del rol', role.hexColor)
      .addField('Miembros con el rol', role.members.size)
      .addField('Mencionable', role.mentionable ? 'Sí' : 'No');

    message.channel.send({ embeds: [roleEmbed] });
  },
};

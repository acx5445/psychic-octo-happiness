const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'userinfo',
  description: 'Muestra información detallada sobre un usuario específico.',
  usage: '!userinfo <mención del usuario>',
  example: '!userinfo @Usuario#1234',
  execute(message) {
    const user = message.mentions.users.first() || message.author;
    const member = message.guild.members.cache.get(user.id);

    const userEmbed = new MessageEmbed()
      .setColor('#0099ff')
      .setTitle(`Información de ${user.tag}`)
      .addField('ID', user.id)
      .addField('Fecha de creación', user.createdAt)
      .addField('Roles', member.roles.cache.map((role) => role.name).join(', '));

    message.channel.send({ embeds: [userEmbed] });
  },
};

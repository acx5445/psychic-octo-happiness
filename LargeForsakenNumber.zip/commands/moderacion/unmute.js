module.exports = {
  name: 'unmute',
  description: 'Quita el silencio a un usuario en el servidor.',
  execute(message, args) {
    if (!message.member.permissions.has('MANAGE_ROLES')) {
      return message.reply('No tienes permiso para usar este comando.');
    }

    const member = message.mentions.members.first();
    if (!member) {
      return message.reply('Debes mencionar a un usuario válido.');
    }

    const muteRole = message.guild.roles.cache.find((role) => role.name === 'Muted');
    if (!muteRole) {
      return message.reply('No se encontró el rol de "Muted" en el servidor.');
    }

    member.roles.remove(muteRole, 'Motivo del unmute')
      .then(() => {
        message.channel.send(`${member.user.tag} ha sido desmuteado.`);
      })
      .catch((error) => {
        console.error(`Error al desmutear
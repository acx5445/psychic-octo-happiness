module.exports = {
  name: 'lock',
  description: 'Bloquea un canal para usuarios sin permisos.',
  execute(message) {
    if (!message.member.permissions.has('MANAGE_CHANNELS')) {
      return message.reply('No tienes permiso para usar este comando.');
    }

    const channel = message.mentions.channels.first() || message.channel;
    if (!channel) {
      return message.reply('Debes mencionar un canal válido.');
    }

    channel.permissionOverwrites.create(channel.guild.roles.everyone, {
      SEND_MESSAGES: false,
    })
      .then(() => {
        message.channel.send(`El canal ${channel} ha sido bloqueado.`);
      })
      .catch((error) => {
        console.error(`Error al bloquear el canal: ${error}`);
        message.reply('Se ha producido un error al bloquear el canal.');
      });
  },
};
      
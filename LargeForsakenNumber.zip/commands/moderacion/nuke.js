module.exports = {
  name: 'nuke',
  description: 'Crea una copia del canal y luego lo elimina, "nukeando" el canal actual.',
  async execute(message) {
    if (!message.member.permissions.has('MANAGE_CHANNELS')) {
      return message.reply('No tienes permiso para usar este comando.');
    }

    const channel = message.channel;

    try {
      const clonedChannel = await channel.clone();
      await channel.delete();
      clonedChannel.send('¡Este canal ha sido nukeado!');
    } catch (error) {
      console.error(`Error al nukear el canal: ${error}`);
      message.reply('Se ha producido un error al nukear el canal.');
    }
  },
};

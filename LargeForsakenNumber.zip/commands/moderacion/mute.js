module.exports = {
  name: 'mute',
  description: 'Silencia a un usuario en el servidor.',
  execute(message, args) {
    if (!message.member.permissions.has('MANAGE_ROLES')) {
      return message.reply('No tienes permiso para usar este comando.');
    }

    const member = message.mentions.members.first();
    if (!member) {
      return message.reply('Debes mencionar a un usuario válido.');
    }

    const muteRole = message.guild.roles.cache.find((role) => role.name === 'Muted');
    if (!muteRole) {
      return message.reply('No se encontró el rol de "Muted" en el servidor.');
    }

    member.roles.add(muteRole, 'Motivo del mute')
      .then(() => {
        message.channel.send(`${member.user.tag} ha sido silenciado.`);
      })
      .catch((error) => {
        console.error(`Error al silenciar al usuario: ${error}`);
        message.reply('Se ha producido un error al silenciar al usuario.');
      });
  },
};
    
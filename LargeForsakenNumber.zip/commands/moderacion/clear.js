module.exports = {
  name: 'clear',
  description: 'Elimina la cantidad especificada de mensajes en el canal actual.',
  async execute(message, args) {
    if (!message.member.permissions.has('MANAGE_MESSAGES')) {
      return message.reply('No tienes permiso para usar este comando.');
    }

    const amount = parseInt(args[0]);

    if (isNaN(amount) || amount < 1 || amount > 100) {
      return message.reply('Debes especificar un número válido entre 1 y 100.');
    }

    try {
      const fetched = await message.channel.messages.fetch({ limit: amount });
      message.channel.bulkDelete(fetched);
    } catch (error) {
      console.error(`Error al eliminar mensajes: ${error}`);
      message.reply('Se ha producido un error al eliminar mensajes.');
    }
  },
};

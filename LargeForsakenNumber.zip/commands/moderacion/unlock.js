module.exports = {
  name: 'unlock',
  description: 'Desbloquea un canal para que todos los usuarios puedan enviar mensajes.',
  execute(message) {
    if (!message.member.permissions.has('MANAGE_CHANNELS')) {
      return message.reply('No tienes permiso para usar este comando.');
    }

    const channel = message.mentions.channels.first() || message.channel;
    if (!channel) {
      return message.reply('Debes mencionar un canal válido.');
    }

    channel.permissionOverwrites.create(channel.guild.roles.everyone, {
      SEND_MESSAGES: true,
    })
      .then(() => {
        message.channel.send(`El canal ${channel} ha sido desbloqueado.`);
      })
      .catch((error) => {
        console.error(`Error al desbloquear el canal: ${error}`);
        message.reply('Se ha producido un error al desbloquear el canal.');
      });
  },
};
const mySecret = process.env['Token']

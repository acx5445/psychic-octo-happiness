module.exports = {
  name: 'kick',
  description: 'Expulsa a un usuario del servidor.',
  execute(message, args) {
    if (!message.member.permissions.has('KICK_MEMBERS')) {
      return message.reply('No tienes permiso para usar este comando.');
    }

    const member = message.mentions.members.first();
    if (!member) {
      return message.reply('Debes mencionar a un usuario válido.');
    }

    if (!member.kickable) {
      return message.reply('No puedo expulsar a este usuario.');
    }

    const reason = args.slice(1).join(' ') || 'No se especificó motivo';
    member.kick(reason)
      .then(() => {
        message.channel.send(`${member.user.tag} ha sido expulsado. Motivo: ${reason}`);
      })
      .catch((error) => {
        console.error(`Error al expulsar al usuario: ${error}`);
        message.reply('Se ha producido un error al expulsar al usuario.');
      });
  },
};
    
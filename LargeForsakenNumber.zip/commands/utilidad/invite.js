module.exports = {
  name: 'invite',
  description: 'Genera un enlace de invitación para agregar el bot a otros servidores.',
  execute(message) {
    const inviteEmbed = new MessageEmbed()
      .setColor('#0099ff')
      .setTitle('Invitar a Sally')
      .setDescription(
        '¡Gracias por querer invitarme a tu servidor! Usa el siguiente enlace para agregarme:'
      )
      .addField('Enlace de Invitación', 'google.com');

    message.channel.send({ embeds: [inviteEmbed] });
  },
};

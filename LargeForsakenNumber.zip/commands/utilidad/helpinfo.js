const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'helpinfo',
  description: 'Muestra información detallada de un comando específico.',
  usage: '!helpinfo <nombre del comando>',
  example: '!helpinfo ping',
  execute(message, args) {
    const commandName = args[0]?.toLowerCase();
    const command = message.client.commands.get(commandName);

    if (commandName && !command) {
      return message.reply('El comando especificado no existe.');
    }

    if (!commandName) {
      return sendCommandList(message);
    }

    const helpEmbed = new MessageEmbed().setColor('#0099ff');

    helpEmbed.setTitle(`Ayuda para el comando "${command.name}"`);
    helpEmbed.setDescription(command.description);
    if (command.usage) {
      helpEmbed.addField('Uso', `\`${command.usage}\``);
    }
    if (command.example) {
      helpEmbed.addField('Ejemplo', `\`${command.example}\``);
    }

    message.channel.send({ embeds: [helpEmbed] });
  },
};

function sendCommandList(message) {
  const helpEmbed = new MessageEmbed()
    .setColor('#0099ff')
    .setTitle('Lista de comandos')
    .setFooter('Usa "!helpinfo <nombre del comando>" para obtener más detalles sobre un comando.');

  message.client.commands.forEach((cmd) => {
    helpEmbed.addField(cmd.name, cmd.description);
  });

  message.channel.send({ embeds: [helpEmbed] });
}

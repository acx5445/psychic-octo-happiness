const { MessageEmbed } = require('discord.js');
const axios = require('axios');

module.exports = {
  name: 'weather',
  description: 'Muestra el pronóstico del tiempo para una ubicación específica.',
  async execute(message, args) {
    // Verifica si se proporcionó una ubicación como argumento.
    if (!args) {
      return message.reply('Debes proporcionar una ubicación para obtener el pronóstico del tiempo.');
    }

    const apiKey = 'YOUR_OPENWEATHERMAP_API_KEY';
    const location = args.join(' ');
    const apiUrl = `http://api.openweathermap.org/data/2.5/weather?q=${encodeURIComponent(
      location
    )}&appid=${apiKey}&units=metric`;

    try {
      const response = await axios.get(apiUrl);
      const weatherData = response.data;

      // Crea el objeto MessageEmbed para mostrar el pronóstico del tiempo.
      const weatherEmbed = new MessageEmbed()
        .setColor('#0099ff')
        .setTitle(`Pronóstico del tiempo para ${weatherData.name}`)
        .setDescription(weatherData.weather[0].description)
        .addField('Temperatura', `${weatherData.main.temp} °C`, true)
        .addField('Humedad', `${weatherData.main.humidity}%`, true)
        .addField('Velocidad del viento', `${weatherData.wind.speed} m/s`, true);

      message.channel.send({ embeds: [weatherEmbed] });
    } catch (error) {
      console.error('Error al obtener el pronóstico del tiempo:', error);
      message.reply('Ocurrió un error al obtener el pronóstico del tiempo. Por favor, intenta nuevamente más tarde.');
    }
  },
};

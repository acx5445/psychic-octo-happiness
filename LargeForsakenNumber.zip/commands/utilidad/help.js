const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'help',
  description: 'Muestra una lista de comandos y su descripción.',
  execute(message) {
    const commandsList = message.client.commands;

    const helpEmbed = new MessageEmbed()
      .setColor('#0099ff')
      .setTitle('Lista de Comandos')
      .setDescription('¡Aquí tienes una lista de comandos disponibles!');

    commandsList.forEach((command) => {
      helpEmbed.addField(command.name, command.description);
    });

    message.channel.send({ embeds: [helpEmbed] });
  },
};

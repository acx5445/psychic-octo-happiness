const { MessageEmbed } = require('discord.js');

const afkUsers = new Map();

module.exports = {
  name: 'afk',
  description: 'Establece el estado AFK   para el usuario.',
  execute(message, args) {
    const reason = args.join(' ') || 'AFK';
    afkUsers.set(message.author.id, { reason, timestamp: Date.now() });

    const afkEmbed = new MessageEmbed()
      .setColor('#0099ff')
      .setTitle('Estado AFK')
      .setDescription(`Ahora estás AFK. Razón: \`${reason}\``);

    message.channel.send({ embeds: [afkEmbed] });
  },
};

// Evento messageCreate para saludar al usuario cuando envíe un mensaje después de estar AFK.
module.exports.events = {
  messageCreate: (message) => {
    const afkData = afkUsers.get(message.author.id);
    if (afkData) {
      afkUsers.delete(message.author.id);

      const duration = getDurationString(afkData.timestamp, Date.now());
      const welcomeBackEmbed = new MessageEmbed()
        .setColor('#0099ff')
        .setTitle('¡Bienvenido de vuelta!')
        .setDescription(`Has estado ausente durante ${duration}.`)
        .addField('Razón', `\`${afkData.reason}\``);

      message.channel.send({ embeds: [welcomeBackEmbed] });
    }
  },
};

// Función para calcular la duración en formato legible.
function getDurationString(start, end) {
  const duration = end - start;
  const seconds = Math.floor(duration / 1000) % 60;
  const minutes = Math.floor(duration / (1000 * 60)) % 60;
  const hours = Math.floor(duration / (1000 * 60 * 60)) % 24;
  const days = Math.floor(duration / (1000 * 60 * 60 * 24));

  const durationString = [];
  if (days > 0) durationString.push(`${days} día${days !== 1 ? 's' : ''}`);
  if (hours > 0) durationString.push(`${hours} hora${hours !== 1 ? 's' : ''}`);
  if (minutes > 0) durationString.push(`${minutes} minuto${minutes !== 1 ? 's' : ''}`);
  if (seconds > 0) durationString.push(`${seconds} segundo${seconds !== 1 ? 's' : ''}`);

  return durationString.join(', ');
                                         }
  
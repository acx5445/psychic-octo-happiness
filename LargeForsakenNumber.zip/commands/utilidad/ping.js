module.exports = {
  name: 'ping',
  description: 'Muestra la latencia del bot.',
  async execute(message) {
    const sentMessage = await message.channel.send('Calculando la latencia...');
    const latency = sentMessage.createdTimestamp - message.createdTimestamp;

    const pingEmbed = new MessageEmbed()
      .setColor('#0099ff')
      .setTitle('Latencia del Bot')
      .addField('Latencia', `${latency} ms`, true)
      .addField('Latencia de la API', `${client.ws.ping} ms`, true);

    sentMessage.edit({ embeds: [pingEmbed] });
  },
};

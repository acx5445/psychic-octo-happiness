const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'serverlist',
  description: 'Muestra una lista de servidores en los que está el bot.',
  execute(message) {
    if (message.author.id !== 'your-discord-user-id') {
      return message.reply('No tienes permiso para usar este comando.');
    }

    const serverListEmbed = new MessageEmbed()
      .setColor('#0099ff')
      .setTitle('Lista de Servidores')
      .setDescription('¡Aquí tienes una lista de servidores en los que estoy presente!');

    const servers = message.client.guilds.cache.map((guild) => guild.name);
    serverListEmbed.addField('Servidores', servers.join('\n'));

    message.channel.send({ embeds: [serverListEmbed] });
  },
};
      
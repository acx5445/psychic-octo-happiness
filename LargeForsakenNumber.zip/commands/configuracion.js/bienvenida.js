const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'bienvenida',
  description: 'Configura el mensaje de bienvenida del servidor.',
  async execute(message, args) {
    if (!message.member.permissions.has('ADMINISTRATOR')) {
      return message.reply('No tienes permiso para configurar el mensaje de bienvenida.');
    }

    const options = {
      channel: message.mentions.channels.first() || message.channel,
      message: '¡Bienvenido/a, {user}! ¡Disfruta de tu estancia en nuestro servidor!',
      image: null,
      dm: false,
    };

    args.forEach((arg, index) => {
      if (arg.startsWith('message:')) {
        options.message = arg.slice('message:'.length).trim();
      } else if (arg.startsWith('image:')) {
        options.image = arg.slice('image:'.length).trim();
      } else if (arg === 'dm') {
        options.dm = true;
      }
    });

    const welcomeEmbed = new MessageEmbed()
      .setColor('#0099ff')
      .setTitle('Mensaje de Bienvenida Configurado')
      .setDescription('El mensaje de bienvenida ha sido configurado correctamente.')
      .addField('Canal', options.channel)
      .addField('Mensaje', options.message)
      .addField('Imagen de Fondo', options.image ? options.image : 'No establecida')
      .addField('Enviar por DM', options.dm ? 'Sí' : 'No');

    message.channel.send({ embeds: [welcomeEmbed] });
  },
};
      
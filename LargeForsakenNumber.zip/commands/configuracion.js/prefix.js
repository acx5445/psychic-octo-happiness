const fs = require('fs');
const { prefix } = require('../../config.js');

module.exports = {
  name: 'prefix',
  description: 'Muestra o cambia el prefijo del bot.',
  execute(message, args) {
    if (!args.length) {
      return message.channel.send(`El prefijo actual es: ${prefix}`);
    }

    if (!message.member.permissions.has('ADMINISTRATOR')) {
      return message.reply('No tienes permiso para cambiar el prefijo.');
    }

    const newPrefix = args[0];
    prefix = newPrefix;

    fs.writeFile('./config.js', `module.exports = { prefix: '${newPrefix}' };`, (err) => {
      if (err) {
        console.error('Error al cambiar el prefijo:', err);
        message.reply('Se ha producido un error al cambiar el prefijo.');
      } else {
        message.channel.send(`El prefijo se ha cambiado a: ${newPrefix}`);
      }
    });
  },
};

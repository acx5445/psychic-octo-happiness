const { MessageEmbed } = require('discord.js');

module.exports = {
  name: 'verificacion',
  description: 'Configura el mensaje de verificación para los nuevos usuarios.',
  async execute(message, args) {
    if (!message.member.permissions.has('ADMINISTRATOR')) {
      return message.reply('No tienes permiso para configurar el mensaje de verificación.');
    }

    const options = {
      message: 'Toca el emoji para darte el rol de usuario.',
      emoji: '👍',
    };

    args.forEach((arg) => {
      if (arg.startsWith('message:')) {
        options.message = arg.slice('message:'.length).trim();
      } else if (arg.startsWith('emoji:')) {
        options.emoji = arg.slice('emoji:'.length).trim();
      }
    });

    const verificationEmbed = new MessageEmbed()
      .setColor('#0099ff')
      .setTitle('Mensaje de Verificación Configurado')
      .setDescription('El mensaje de verificación ha sido configurado correctamente.')
      .addField('Mensaje', options.message)
      .addField('Emoji', options.emoji);

    message.channel.send({ embeds: [verificationEmbed] });
  },
};
      